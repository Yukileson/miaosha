package com.miaosha.miaosha;

import com.miaosha.domain.MiaoshaUser;
import com.miaosha.service.MiaoshaUserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiaoshaApplicationTests {



    @Autowired
    MiaoshaUserService miaoshaUserService;

    @Test
    void contextLoads() {
        String mobile = "15151410341";
        MiaoshaUser miaoshaUser = miaoshaUserService.getById(Long.parseLong(mobile));
        System.out.println(miaoshaUser);
    }

}
