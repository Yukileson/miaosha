package com.miaosha.service;

import com.miaosha.domain.MiaoshaUser;
import com.miaosha.domain.OrderInfo;
import com.miaosha.vo.GoodsVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MiaoshaService {

    @Autowired
    GoodsService goodsService;

    @Autowired
    OrderService orderService;

    public OrderInfo miaosha(MiaoshaUser user, GoodsVo goods) {

        //减库存
        goodsService.reduceStock(goods);
        return orderService.createOrder(user,goods);
    }
}
